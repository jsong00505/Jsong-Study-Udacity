#Project 2

* NAME: Jun Song
* TIME: almost 3 hours took

## Challenge

* I was confused about how to make the globe spin. That is because it didn't work well. You could check my problem was [here](https://discussions.udacity.com/t/spinning-globe-not-stopping-after-click/196334/28?u=june_622016308842413).
* The globe spin was the hardest challenge to me.

## Resubmit
* 06/11/2016: Just update bake resolution 80.
